extern void ignore(void);

void ignore(void)
{
	/* libcompat.a cannot be empty therefore I exist */
}
