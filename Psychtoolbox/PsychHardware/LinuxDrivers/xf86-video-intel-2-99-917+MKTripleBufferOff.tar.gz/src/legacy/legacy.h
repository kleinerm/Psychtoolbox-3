/* The old i810 (only) driver. */
const OptionInfoRec *lg_i810_available_options(int chipid, int busid);
Bool lg_i810_init(ScrnInfoPtr scrn);
