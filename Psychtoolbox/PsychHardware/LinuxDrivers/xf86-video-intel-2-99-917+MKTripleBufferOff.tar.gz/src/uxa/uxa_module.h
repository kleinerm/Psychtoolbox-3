#ifndef INTEL_MODULE_H
#define INTEL_MODULE_H

extern Bool intel_init_scrn(ScrnInfoPtr scrn);

#endif /* INTEL_MODULE_H */
