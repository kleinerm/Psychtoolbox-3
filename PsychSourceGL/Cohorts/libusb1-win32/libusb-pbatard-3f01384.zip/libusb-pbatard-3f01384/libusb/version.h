/* This file is parsed by m4 and windres and RC.EXE so please keep it simple. */
#ifndef LIBUSB_MAJOR
#define LIBUSB_MAJOR 1
#endif
#ifndef LIBUSB_MINOR
#define LIBUSB_MINOR 0
#endif
#ifndef LIBUSB_MICRO
#define LIBUSB_MICRO 8
#endif
#ifndef LIBUSB_NANO
#define LIBUSB_NANO 10341
#endif
