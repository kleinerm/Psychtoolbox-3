Purpose:
========

These files need to be installed in the Registry and Matlab folders if you want
to use the latest Microsoft Visual Studio 2019 with Matlab R2019a:

Credits:
========

The files msvc2019 and msvcpp2019 are taken from a Matlab answers thread:

https://www.mathworks.com/matlabcentral/answers/454296-can-i-use-microsoft-visual-studio-2019-with-matlab-r2019a-or-r2018b

I also took instructions for editing the registry from there and turned them into a .reg registry update file named

add_msvc2019_buildtools.reg 

How to setup:
=============

1. Copy them into C:\Program Files\MATLAB\R2018b\bin\win64\mexopts\

2. Then double-click on the given registry file add_msvc2019_buildtools.reg to add a registry key so above files can find MSVC 2019 compilers and SDK's.

3. Restart Matlab.

4. mex -setup

=> Tested with MSVC2019 + R2019a on a Windows 10 system.
